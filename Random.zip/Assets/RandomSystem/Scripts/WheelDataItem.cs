using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class WheelDataItem : MonoBehaviour
{
    public TMP_InputField nameInput;
    public TextMeshProUGUI ProbabilityText;
    public Slider probabilitySlider;

    public Image colorImage;
    public Slider RSlider;
    public Slider GSlider;
    public Slider BSlider;

    public Button removeBtn;


    public string sectorName;
    public Color sectorColor ;
    public int percentage;

   


}
